import PlayersWidget from "scenes/widgets/PlayersWidget"

const PlayerPage = () => {
    return (
        <PlayersWidget />
    )
}

export default PlayerPage